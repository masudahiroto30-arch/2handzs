# Closet Seller Pro V2

ระบบจัดการร้านเสื้อผ้ามือ 1 และมือ 2

## มีอะไรเพิ่มจาก V1
- อัปโหลดรูปสินค้าได้สูงสุด 8 รูป และเก็บใน browser
- ขนาดสินค้า: อก / ยาว / เอว / สะโพก
- ช่องบันทึกตำหนิสำหรับเสื้อผ้ามือสอง
- สร้าง Caption พร้อมข้อมูลไซซ์/ตำหนิ/แฮชแท็ก
- ปุ่ม Copy สำหรับ Facebook, Instagram, TikTok
- สร้างออเดอร์จากสินค้า
- ติดตามสถานะชำระเงิน/แพ็ก/ส่ง และเลขพัสดุ
- Dashboard รายได้ กำไร และสต็อก
- ค้นหาและกรองสินค้า
- Responsive มือถือ
- ใช้ Local Storage ไม่ต้องมี database/API

## Deploy Vercel
อัปโหลดไฟล์ทั้งหมดขึ้น GitHub แล้ว Import repository ใน Vercel
Build command: npm run build
