import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title:"Closet Seller Pro V2", description:"ระบบจัดการร้านเสื้อผ้ามือหนึ่งและมือสอง" };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="th"><body>{children}</body></html>}
