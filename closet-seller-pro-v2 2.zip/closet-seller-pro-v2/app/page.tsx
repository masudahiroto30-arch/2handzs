"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  Archive, BarChart3, Check, ChevronDown, Clipboard, Copy, Facebook,
  FileText, ImagePlus, Instagram, LayoutDashboard, Package, Pencil,
  Plus, Search, ShoppingBag, Sparkles, Tag, Trash2, Truck, UserRound,
  X, Wallet, MessageCircle
} from "lucide-react";

type Status = "ร่าง"|"พร้อมลงขาย"|"ลงขายแล้ว"|"จองแล้ว"|"ขายแล้ว"|"ส่งแล้ว";
type Channel = "Facebook"|"Instagram"|"TikTok"|"Shopee"|"Marketplace"|"LINE";
type Item = {
  id:string; title:string; type:"มือ 1"|"มือ 2"; category:string; brand:string;
  size:string; color:string; condition:string; price:number; cost:number; stock:number;
  status:Status; channel:Channel; description:string; defect:string; chest:string;
  length:string; waist:string; hip:string; images:string[]; created:string;
};
type Order = {id:string; itemId:string; buyer:string; channel:Channel; amount:number; status:"รอชำระ"|"ชำระแล้ว"|"กำลังแพ็ก"|"ส่งแล้ว"|"ยกเลิก"; tracking:string; created:string};

const seed:Item[]=[
 {id:"1",title:"เสื้อเชิ้ต Oxford แขนยาว สีฟ้า",type:"มือ 1",category:"เสื้อเชิ้ต",brand:"Uniqlo",size:"L",color:"ฟ้า",condition:"ใหม่ มีป้าย",price:590,cost:320,stock:3,status:"พร้อมลงขาย",channel:"Facebook",description:"เสื้อเชิ้ต Oxford ทรงสวย ใส่ทำงานหรือแต่งลำลองได้",defect:"",chest:"42",length:"29",waist:"",hip:"",images:[],created:"2026-10-07"},
 {id:"2",title:"Vintage Denim Jacket",type:"มือ 2",category:"แจ็กเก็ต",brand:"Levi's",size:"M",color:"ยีนส์",condition:"มือสอง สภาพดี",price:890,cost:450,stock:1,status:"พร้อมลงขาย",channel:"Instagram",description:"แจ็กเก็ตยีนส์วินเทจ ทรงสวย มีร่องรอยการใช้งานเล็กน้อย",defect:"มีรอยเฟดตามธรรมชาติ",chest:"40",length:"25",waist:"",hip:"",images:[],created:"2026-10-07"}
];
const blank:Omit<Item,"id"|"created">={title:"",type:"มือ 2",category:"เสื้อยืด",brand:"",size:"M",color:"",condition:"มือสอง สภาพดี",price:0,cost:0,stock:1,status:"ร่าง",channel:"Facebook",description:"",defect:"",chest:"",length:"",waist:"",hip:"",images:[]};

const money=(n:number)=>new Intl.NumberFormat("th-TH",{maximumFractionDigits:0}).format(n);
const caption=(x:Item)=>{
 const measure=[x.chest&&`อก ${x.chest}"`,x.length&&`ยาว ${x.length}"`,x.waist&&`เอว ${x.waist}"`,x.hip&&`สะโพก ${x.hip}"`].filter(Boolean).join(" | ");
 return `✨ ${x.title}
🏷️ ${x.brand||"ไม่ระบุแบรนด์"} | ไซซ์ ${x.size} | สี${x.color||"-"}
${x.type==="มือ 1"?"🆕 สินค้าใหม่":"♻️ มือสอง"} · ${x.condition}
💰 ราคา ${money(x.price)} บาท
${measure?`📏 ${measure}\n`:""}${x.defect?`⚠️ ตำหนิ: ${x.defect}\n`:""}
${x.description||"งานสวย พร้อมใส่ สนใจทักแชตได้เลยครับ/ค่ะ"}

#เสื้อผ้า #เสื้อผ้ามือสอง #เสื้อผ้ามือหนึ่ง #แฟชั่น #ของดีบอกต่อ`;
};

export default function Home(){
 const [items,setItems]=useState<Item[]>([]);
 const [orders,setOrders]=useState<Order[]>([]);
 const [tab,setTab]=useState("dashboard");
 const [query,setQuery]=useState(""); const [type,setType]=useState("ทั้งหมด"); const [status,setStatus]=useState("ทั้งหมด");
 const [formOpen,setFormOpen]=useState(false); const [editing,setEditing]=useState<Item|null>(null); const [form,setForm]=useState(blank);
 const [selected,setSelected]=useState<Item|null>(null); const [copied,setCopied]=useState(""); const fileRef=useRef<HTMLInputElement>(null);

 useEffect(()=>{const a=localStorage.getItem("closet-v2-items");setItems(a?JSON.parse(a):seed);const b=localStorage.getItem("closet-v2-orders");setOrders(b?JSON.parse(b):[])},[]);
 useEffect(()=>{if(items.length)localStorage.setItem("closet-v2-items",JSON.stringify(items))},[items]);
 useEffect(()=>{localStorage.setItem("closet-v2-orders",JSON.stringify(orders))},[orders]);

 const stats=useMemo(()=>{
  const active=items.filter(x=>x.status!=="ขายแล้ว"&&x.status!=="ส่งแล้ว");
  return {total:items.length,ready:items.filter(x=>x.status==="พร้อมลงขาย").length,sold:items.filter(x=>x.status==="ขายแล้ว"||x.status==="ส่งแล้ว").length,
   value:active.reduce((s,x)=>s+x.price*x.stock,0),profit:active.reduce((s,x)=>s+Math.max(0,x.price-x.cost)*x.stock,0),
   revenue:orders.filter(x=>x.status!=="ยกเลิก").reduce((s,x)=>s+x.amount,0)};
 },[items,orders]);

 const filtered=useMemo(()=>items.filter(x=>{
  const q=query.toLowerCase().trim(); const mq=!q||[x.title,x.brand,x.category,x.size,x.color].join(" ").toLowerCase().includes(q);
  return mq&&(type==="ทั้งหมด"||x.type===type)&&(status==="ทั้งหมด"||x.status===status);
 }),[items,query,type,status]);

 function openAdd(){setEditing(null);setForm(blank);setFormOpen(true)}
 function edit(x:Item){setEditing(x);setForm({...x});setFormOpen(true)}
 function save(){if(!form.title.trim())return; if(editing)setItems(a=>a.map(x=>x.id===editing.id?{...editing,...form}:x));else setItems(a=>[{...form,id:crypto.randomUUID(),created:new Date().toISOString().slice(0,10)},...a]);setFormOpen(false)}
 function remove(id:string){if(confirm("ลบสินค้านี้ใช่ไหม?"))setItems(a=>a.filter(x=>x.id!==id))}
 async function copy(text:string,label:string){await navigator.clipboard?.writeText(text);setCopied(label);setTimeout(()=>setCopied(""),1500)}
 async function images(files:FileList|null){
  if(!files)return; const arr=Array.from(files).slice(0,8);
  const data=await Promise.all(arr.map(f=>new Promise<string>(res=>{const r=new FileReader();r.onload=()=>res(String(r.result));r.readAsDataURL(f)})));
  setForm(f=>({...f,images:[...f.images,...data].slice(0,8)}));
 }
 function addOrder(item:Item){const buyer=prompt("ชื่อลูกค้า");if(!buyer)return;setOrders(o=>[{id:crypto.randomUUID(),itemId:item.id,buyer,channel:item.channel,amount:item.price,status:"รอชำระ",tracking:"",created:new Date().toISOString().slice(0,10)},...o]);setSelected(null)}
 return <main>
  <aside className="sidebar">
   <div className="brand"><div className="brand-mark"><ShoppingBag size={21}/></div><div><b>Closet Seller</b><span>PRO V2</span></div></div>
   <nav>
    <Nav active={tab==="dashboard"} onClick={()=>setTab("dashboard")} icon={<LayoutDashboard/>}>ภาพรวม</Nav>
    <Nav active={tab==="items"} onClick={()=>setTab("items")} icon={<Package/>}>สินค้า</Nav>
    <Nav active={tab==="content"} onClick={()=>setTab("content")} icon={<Sparkles/>}>สร้างโพสต์</Nav>
    <Nav active={tab==="orders"} onClick={()=>setTab("orders")} icon={<Truck/>}>ออเดอร์</Nav>
   </nav>
   <div className="side-tip"><Sparkles size={18}/><b>ร้านพร้อมขาย</b><p>เพิ่มรูป วัดไซซ์ ระบุตำหนิ แล้วคัดลอกโพสต์ไปลง Social ได้ทันที</p><button onClick={openAdd}>+ เพิ่มสินค้า</button></div>
  </aside>
  <section className="main">
   <header className="topbar"><div><div className="eyebrow">CLOSET SELLER PRO</div><h1>{tab==="dashboard"?"จัดการร้านเสื้อผ้า":tab==="items"?"สินค้าของฉัน":tab==="content"?"สร้างโพสต์ขาย":"จัดการออเดอร์"}</h1></div><button className="primary" onClick={openAdd}><Plus size={18}/> เพิ่มสินค้า</button></header>

   {tab==="dashboard"&&<><section className="hero"><div><div className="pill">มือ 1 + มือ 2</div><h2>ลงขายเสื้อผ้า<br/>ให้เป็นระบบมากขึ้น</h2><p>เก็บรูป รายละเอียด ไซซ์ ต้นทุน ราคา และสถานะการขายไว้ในที่เดียว</p><button className="primary light" onClick={openAdd}><ImagePlus size={18}/> เพิ่มสินค้าและรูป</button></div><div className="hero-card"><Wallet size={22}/><b>รายได้จากออเดอร์</b><strong>฿{money(stats.revenue)}</strong><span>รวมออเดอร์ที่ไม่ถูกยกเลิก</span></div></section>
    <div className="stats"><Stat icon={<Package/>} label="สินค้าทั้งหมด" value={stats.total}/><Stat icon={<Check/>} label="พร้อมลงขาย" value={stats.ready}/><Stat icon={<Archive/>} label="ขายแล้ว" value={stats.sold}/><Stat icon={<Tag/>} label="กำไรคาดการณ์" value={`฿${money(stats.profit)}`}/></div>
    <section className="section"><Head title="สินค้าแนะนำให้จัดการ" sub="รายการล่าสุด"/><div className="grid">{items.slice(0,4).map(x=><Card key={x.id} item={x} open={setSelected} edit={edit}/>)}</div></section>
    <section className="quick"><div><BarChart3 size={20}/><b>ขั้นตอนแนะนำ</b><span>1. เพิ่มรูป → 2. ใส่รายละเอียด → 3. สร้าง Caption → 4. ลงขาย → 5. บันทึกออเดอร์</span></div></section>
   </>}

   {tab==="items"&&<section><div className="toolbar"><div className="search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="ค้นหาชื่อ แบรนด์ หมวดหมู่ ไซซ์..."/></div><Select value={type} onChange={setType} options={["ทั้งหมด","มือ 1","มือ 2"]}/><Select value={status} onChange={setStatus} options={["ทั้งหมด","ร่าง","พร้อมลงขาย","ลงขายแล้ว","จองแล้ว","ขายแล้ว","ส่งแล้ว"]}/></div><div className="grid">{filtered.map(x=><Card key={x.id} item={x} open={setSelected} edit={edit}/>)}</div>{!filtered.length&&<Empty/>}</section>}

   {tab==="content"&&<Content items={items} selected={selected} setSelected={setSelected} copy={copy} copied={copied}/>}
   {tab==="orders"&&<Orders orders={orders} items={items} setOrders={setOrders}/>}
  </section>

  {formOpen&&<div className="modal-bg" onMouseDown={()=>setFormOpen(false)}><div className="modal" onMouseDown={e=>e.stopPropagation()}>
   <div className="modal-head"><div><span className="label">PRODUCT MANAGEMENT</span><h2>{editing?"แก้ไขสินค้า":"เพิ่มสินค้าใหม่"}</h2></div><button className="icon-btn" onClick={()=>setFormOpen(false)}><X/></button></div>
   <div className="form-grid">
    <Field label="ชื่อสินค้า *" full><input value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="เช่น เสื้อยืด Oversize สีดำ"/></Field>
    <Field label="ประเภท"><Select value={form.type} onChange={v=>setForm({...form,type:v as Item["type"]})} options={["มือ 1","มือ 2"]}/></Field>
    <Field label="หมวดหมู่"><Select value={form.category} onChange={v=>setForm({...form,category:v})} options={["เสื้อยืด","เสื้อเชิ้ต","กางเกง","กระโปรง","เดรส","แจ็กเก็ต","เสื้อคลุม","รองเท้า","กระเป๋า","อื่นๆ"]}/></Field>
    <Field label="แบรนด์"><input value={form.brand} onChange={e=>setForm({...form,brand:e.target.value})} placeholder="ไม่ระบุได้"/></Field>
    <Field label="ไซซ์"><input value={form.size} onChange={e=>setForm({...form,size:e.target.value})} placeholder="S / M / L / XL"/></Field>
    <Field label="สี"><input value={form.color} onChange={e=>setForm({...form,color:e.target.value})} placeholder="ดำ"/></Field>
    <Field label="สภาพ"><Select value={form.condition} onChange={v=>setForm({...form,condition:v})} options={["ใหม่ มีป้าย","ใหม่ ไม่มีป้าย","มือสอง สภาพดี","มือสอง มีตำหนิ","Vintage"]}/></Field>
    <Field label="ราคาขาย"><input type="number" value={form.price} onChange={e=>setForm({...form,price:Number(e.target.value)})}/></Field>
    <Field label="ต้นทุน"><input type="number" value={form.cost} onChange={e=>setForm({...form,cost:Number(e.target.value)})}/></Field>
    <Field label="สต็อก"><input type="number" min="0" value={form.stock} onChange={e=>setForm({...form,stock:Number(e.target.value)})}/></Field>
    <Field label="ช่องทาง"><Select value={form.channel} onChange={v=>setForm({...form,channel:v as Channel})} options={["Facebook","Instagram","TikTok","Shopee","Marketplace","LINE"]}/></Field>
    <Field label="สถานะ"><Select value={form.status} onChange={v=>setForm({...form,status:v as Status})} options={["ร่าง","พร้อมลงขาย","ลงขายแล้ว","จองแล้ว","ขายแล้ว","ส่งแล้ว"]}/></Field>
    <Field label="รอบอก (นิ้ว)"><input value={form.chest} onChange={e=>setForm({...form,chest:e.target.value})} placeholder="เช่น 40"/></Field>
    <Field label="ความยาว (นิ้ว)"><input value={form.length} onChange={e=>setForm({...form,length:e.target.value})}/></Field>
    <Field label="เอว (นิ้ว)"><input value={form.waist} onChange={e=>setForm({...form,waist:e.target.value})}/></Field>
    <Field label="สะโพก (นิ้ว)"><input value={form.hip} onChange={e=>setForm({...form,hip:e.target.value})}/></Field>
    <Field label="รายละเอียด / จุดขาย" full><textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="วัสดุ ทรง การใช้งาน ฯลฯ"/></Field>
    <Field label="ตำหนิ (สำคัญสำหรับมือสอง)" full><textarea value={form.defect} onChange={e=>setForm({...form,defect:e.target.value})} placeholder="เช่น มีรอยเล็กบริเวณแขนซ้าย หรือ ไม่มีตำหนิ"/></Field>
    <div className="field full"><span>รูปสินค้า สูงสุด 8 รูป</span><button className="upload" onClick={()=>fileRef.current?.click()}><ImagePlus size={18}/> เลือกรูปจากเครื่อง</button><input ref={fileRef} hidden type="file" accept="image/*" multiple onChange={e=>images(e.target.files)}/>{form.images.length>0&&<div className="thumbs">{form.images.map((src,i)=><div className="thumb" key={i}><img src={src}/><button onClick={()=>setForm(f=>({...f,images:f.images.filter((_,n)=>n!==i)}))}><X size={12}/></button></div>)}</div>}</div>
   </div>
   <div className="modal-foot"><button className="ghost" onClick={()=>setFormOpen(false)}>ยกเลิก</button><button className="primary" onClick={save}><Check size={17}/> บันทึกสินค้า</button></div>
  </div></div>}

  {selected&&<div className="modal-bg" onMouseDown={()=>setSelected(null)}><div className="modal detail" onMouseDown={e=>e.stopPropagation()}>
   <div className="modal-head"><div><span className="label">{selected.type}</span><h2>{selected.title}</h2></div><button className="icon-btn" onClick={()=>setSelected(null)}><X/></button></div>
   <div className="detail-grid"><div><div className="gallery">{selected.images.length?selected.images.map((s,i)=><img key={i} src={s}/>):<div className="no-photo"><ImagePlus size={40}/><span>ยังไม่มีรูปสินค้า</span></div>}</div></div>
    <div><div className="detail-price">฿{money(selected.price)}</div><div className="chips"><span>{selected.brand||"ไม่ระบุแบรนด์"}</span><span>ไซซ์ {selected.size}</span><span>{selected.color||"ไม่ระบุสี"}</span><span>{selected.condition}</span></div>
    <p>{selected.description||"ยังไม่มีรายละเอียดสินค้า"}</p>{selected.defect&&<div className="defect"><b>ตำหนิ:</b> {selected.defect}</div>}
    <div className="measure">{selected.chest&&<span>อก {selected.chest}"</span>}{selected.length&&<span>ยาว {selected.length}"</span>}{selected.waist&&<span>เอว {selected.waist}"</span>}{selected.hip&&<span>สะโพก {selected.hip}"</span>}</div>
    <div className="profit-box"><span>กำไรต่อชิ้น</span><b>฿{money(Math.max(0,selected.price-selected.cost))}</b></div>
    <div className="detail-actions"><button className="primary" onClick={()=>copy(caption(selected),"detail")}><Copy size={17}/>{copied==="detail"?"คัดลอกแล้ว":"คัดลอก Caption"}</button><button className="outline" onClick={()=>{setSelected(null);edit(selected)}}><Pencil size={17}/>แก้ไข</button><button className="outline" onClick={()=>addOrder(selected)}><Truck size={17}/>สร้างออเดอร์</button><button className="danger" onClick={()=>{remove(selected.id);setSelected(null)}}><Trash2 size={17}/>ลบ</button></div></div>
   </div>
  </div></div>}
  {copied&&<div className="toast"><Check size={17}/> คัดลอกแล้ว</div>}
 </main>
}

function Nav({active,onClick,icon,children}:{active:boolean;onClick:()=>void;icon:React.ReactNode;children:React.ReactNode}){return <button className={active?"nav active":"nav"} onClick={onClick}>{icon}{children}</button>}
function Stat({icon,label,value}:{icon:React.ReactNode;label:string;value:string|number}){return <div className="stat"><div className="stat-icon">{icon}</div><div><span>{label}</span><strong>{value}</strong></div></div>}
function Head({title,sub}:{title:string;sub:string}){return <div className="section-head"><div><h3>{title}</h3><p>{sub}</p></div></div>}
function Select({value,onChange,options}:{value:string;onChange:(v:string)=>void;options:string[]}){return <div className="select"><select value={value} onChange={e=>onChange(e.target.value)}>{options.map(x=><option key={x}>{x}</option>)}</select><ChevronDown size={15}/></div>}
function Field({label,children,full=false}:{label:string;children:React.ReactNode;full?:boolean}){return <label className={full?"field full":"field"}><span>{label}</span>{children}</label>}
function Empty(){return <div className="empty"><Package size={34}/><b>ยังไม่พบสินค้า</b><span>ลองเปลี่ยนตัวกรองหรือเพิ่มสินค้าใหม่</span></div>}
function Card({item,open,edit}:{item:Item;open:(x:Item)=>void;edit:(x:Item)=>void}){return <article className="product-card">
 <button className="product-photo" onClick={()=>open(item)}>{item.images[0]?<img src={item.images[0]}/>:<div>{item.type==="มือ 1"?"NEW":"SECOND"}</div>}<span>{item.images.length?`${item.images.length} รูป`:"เพิ่มรูปสินค้า"}</span></button>
 <div className="product-body"><div className="product-top"><span className={item.type==="มือ 1"?"badge new":"badge second"}>{item.type}</span><span className="status">{item.status}</span></div>
 <button className="title-btn" onClick={()=>open(item)}>{item.title}</button><p className="meta">{item.brand||"ไม่ระบุแบรนด์"} · {item.size} · {item.color||"ไม่ระบุสี"}</p>
 <div className="price-row"><strong>฿{money(item.price)}</strong><span>กำไร ฿{money(Math.max(0,item.price-item.cost))}</span></div>
 <div className="card-actions"><button className="outline small" onClick={()=>open(item)}><FileText size={15}/> รายละเอียด</button><button className="icon-btn small-icon" onClick={()=>edit(item)}><Pencil size={16}/></button></div></div></article>}
function Content({items,selected,setSelected,copy,copied}:{items:Item[];selected:Item|null;setSelected:(x:Item|null)=>void;copy:(x:string,l:string)=>void;copied:string}){return <section className="content-page"><Head title="สร้างโพสต์ขาย" sub="เลือกสินค้า แล้วคัดลอกโพสต์พร้อมรายละเอียดและแฮชแท็ก"/><div className="content-layout"><div className="list-panel">{items.map(x=><button className={`content-item ${selected?.id===x.id?"selected":""}`} key={x.id} onClick={()=>setSelected(x)}><div className="mini-photo">{x.images[0]?<img src={x.images[0]}/>:x.type==="มือ 1"?"NEW":"2ND"}</div><div><b>{x.title}</b><span>฿{money(x.price)} · {x.channel}</span></div></button>)}</div><div className="caption-panel">{selected?<><div className="caption-top"><div><span className="label">POST READY</span><h3>{selected.title}</h3></div></div><textarea readOnly value={caption(selected)}/><div className="caption-actions"><button className="primary" onClick={()=>copy(caption(selected),"caption")}><Copy size={17}/>{copied==="caption"?"คัดลอกแล้ว":"คัดลอกทั้งหมด"}</button><button className="outline" onClick={()=>copy(caption(selected),"fb")}><Facebook size={17}/> Facebook</button><button className="outline" onClick={()=>copy(caption(selected),"ig")}><Instagram size={17}/> Instagram</button><button className="outline" onClick={()=>copy(caption(selected),"tt")}><MessageCircle size={17}/> TikTok</button></div></>:<Empty/>}</div></div></section>}
function Orders({orders,items,setOrders}:{orders:Order[];items:Item[];setOrders:React.Dispatch<React.SetStateAction<Order[]>>}){return <section><Head title="ออเดอร์" sub="ติดตามสถานะลูกค้า การชำระเงิน และเลขพัสดุ"/>{orders.length?<div className="orders">{orders.map(o=>{const item=items.find(x=>x.id===o.itemId);return <div className="order" key={o.id}><div className="order-icon"><Truck size={19}/></div><div className="order-main"><b>{item?.title||"สินค้าถูกลบ"}</b><span><UserRound size={13}/> {o.buyer} · {o.channel} · {o.created}</span></div><strong>฿{money(o.amount)}</strong><Select value={o.status} onChange={v=>setOrders(a=>a.map(x=>x.id===o.id?{...x,status:v as Order["status"]}:x))} options={["รอชำระ","ชำระแล้ว","กำลังแพ็ก","ส่งแล้ว","ยกเลิก"]}/><input className="tracking" value={o.tracking} onChange={e=>setOrders(a=>a.map(x=>x.id===o.id?{...x,tracking:e.target.value}:x))} placeholder="เลขพัสดุ"/></div>})}</div>:<Empty/>}</section>}
